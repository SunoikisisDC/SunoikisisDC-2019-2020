Three photographs of the British Museum 
Hoa Hakananai'a display, taken on 2019-07-07 by Andrea Wallace.

These photographs are in the Public Domain [CC0](https://creativecommons.org/publicdomain/zero/1.0/)