Originally published: 2019-11-17
This version: 2

*******************

GENERAL INFORMATION

*******************


1. TITLE

Example dataset accompanying Session 8, "GIS and Geovisualization," Sunoikisis Digital Cultural Heritage, Fall 2019

2. AUTHOR INFORMATION

Dr. Rebecca M. Seifried
University of Massachusetts Amherst
Amherst, MA, USA
rseifried@umass.edu
rmseifried@gmail.com (permanent)

3. DESCRIPTION

GIS data for experimenting with least-cost analysis, following the route that Colonel William Leake visited in the southern Peloponnese in 1805. The exercise and a link to the video tutorial can be found at: https://github.com/SunoikisisDC/SunoikisisDC-2019-2020/wiki/DCH-Session-8-GIS-and-Geovisualization

4. LICENSES

This data package is made available under the Creative Commons Attribution 4.0 International License: https://creativecommons.org/licenses/by/4.0/legalcode.


**********************

DATA AND FILE OVERVIEW

**********************


1. FILE LIST

A. Leake_waypoints.shp

Coordinates of 18 waypoints where Leake stopped during his journey in the southern Mani peninsula, according to his account (Leake 1830). WAYPOINT NUMBER represents the order in which Leake visited each point, from 1 to 17. Leake did not stop at Point 0 (Karyoupoli), but he passed it while traveling between points 8 (Skoutari) and 9 (Areopoli). It may be used as an intermediate point when conducting least-cost analysis. The shapefile was projected from WGS84 (decimal degree) using the "Save Features As..." command in QGIS 3.4. Projected Coordinate System: WGS84 UTM Zone 34N.

This shapefile is extracted from a larger dataset (Seifried and Gardner 2018), which can be accessed online: http://doi.org/10.5281/zenodo.2233046

B. SRTM1_Clip.tif and SRTM1_Hillshade.tif

Extract of SRTM 1 Arc-Second Global data retrieved from the online USGS Earth Explorer, courtesy the USGS/Earth Resources Observation and Science (EROS) Center. The clip was extracted from tile SRTM1N36E022V3 and projected from WGS84 (decimal degree) using the "Warp (Reproject)" tool in QGIS 3.4. The hillside was created using the "Hillside" tool in QGIS 3.4. Projected Coordinate System: WGS84 UTM Zone 34N.

C. Greece_boundary.shp

Description: Level 0 boundary for the country of Greece, downloaded from GADM (https://gadm.org/download_country_v3.html). The shapefile was projected from WGS84 (decimal degree) using the "Save Features As..." command in QGIS 3.4. Projected Coordinate System: WGS84 UTM Zone 34N.


**********

REFERENCES

**********

Leake, William Martin. 1830. Travels in the Morea: With a Map and Plans. Vol. 1. John Murray, London.

Seifried, Rebecca M. and Chelsea A.M. Gardner (2018). Data package for modeling the journey of Colonel William Leake in the southern Mani Peninsula, Greece, using least-cost analysis [Data set]. Zenodo. http://doi.org/10.5281/zenodo.2233046
